package trabalho_2;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class main {

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            JFrame frame = new JFrame("Tela de Login");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 300); // Ajuste o tamanho conforme sua necessidade
            
            Login painelLogin = new Login();  // Seu JPanel
            frame.setContentPane(painelLogin);

            frame.setLocationRelativeTo(null); // Centralizar na tela
            frame.setVisible(true);
        });
    }
}
