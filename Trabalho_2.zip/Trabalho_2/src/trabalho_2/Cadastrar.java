package trabalho_2;

import javax.swing.*;                     
import javax.swing.event.DocumentListener; 
import javax.swing.event.DocumentEvent;    
import java.text.SimpleDateFormat;        
import java.text.ParseException;          
import java.util.Calendar;                 
import java.util.Date;
import java.sql.*;

public class Cadastrar extends javax.swing.JFrame {

    // Configurações do banco
    private final String driverJDBC = "com.mysql.cj.jdbc.Driver";
    private final String url = "jdbc:mysql://127.0.0.1:3306/veiculos";
    private final String user = "root";
    private final String senha = "Davi100445#";
    private Connection conexao;

    public Cadastrar() {
        initComponents();
        this.setLocationRelativeTo(null);
        configurarRadioButtons();
        configurarValidacaoCampos();
        btnSubmit.setEnabled(false);
        verificarCampos();

        try {
            Class.forName(driverJDBC);
            conexao = DriverManager.getConnection(url, user, senha);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao conectar no banco: " + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void cadastrarVeiculo() {
        try {
            // Dados comuns
            String placa = campoPlaca.getText().trim();
            String modelo = campoModelo.getText().trim();
            String marca = campoMarca.getText().trim();
            String cor = campoCor.getText().trim();
            float preco = Float.parseFloat(campoPreco.getText().trim());

            String dataTexto = campoDataFabricacao.getText().trim();
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);
            java.util.Date dataUtil = sdf.parse(dataTexto);
            java.sql.Date dataFabricacao = new java.sql.Date(dataUtil.getTime());

            conexao.setAutoCommit(false);

            // Insere na tabela veiculo
            String sqlVeiculo = "INSERT INTO veiculo (placa, modelo, marca, cor, preco, data_fabricacao) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement psVeiculo = conexao.prepareStatement(sqlVeiculo, Statement.RETURN_GENERATED_KEYS);
            psVeiculo.setString(1, placa);
            psVeiculo.setString(2, modelo);
            psVeiculo.setString(3, marca);
            psVeiculo.setString(4, cor);
            psVeiculo.setFloat(5, preco);
            psVeiculo.setDate(6, dataFabricacao);
            psVeiculo.executeUpdate();

            ResultSet rs = psVeiculo.getGeneratedKeys();
            int idVeiculo = -1;
            if (rs.next()) {
                idVeiculo = rs.getInt(1);
            } else {
                throw new SQLException("Falha ao obter ID do veículo inserido.");
            }

            if (panelSUV.isVisible()) {
                // Captura dados SUV
                int qtdPortas = Integer.parseInt(campoQtdPortas.getSelectedItem().toString().trim());
                int alturaSolo = Integer.parseInt(campoAlturaSolo.getText().trim());
                int qtdAirbags = Integer.parseInt(campoQtdAirbags.getText().trim());
                int capacidadePassageiros = Integer.parseInt(campoQtdPassageiros.getText().trim());

                boolean arCondicionado = rbArCondicionadoSim.isSelected();
                boolean freioABS = rbFreioABSSim.isSelected();
                boolean tracao4x4 = rbTracao4x4Sim.isSelected();

                String tipoCambio = campoTipoCambio.getSelectedItem().toString().trim();
                String tipoDirecao = campoTipoDirecao.getSelectedItem().toString().trim();
                String tipoCombustivel = campoTipoCombustivel.getSelectedItem().toString().trim();

                String sqlSUV = "INSERT INTO suv (id_veiculo, qtd_portas, altura_solo, qtd_airbags, capacidade_passageiros, ar_condicionado, freio_abs, tracao_4x4, tipo_cambio, tipo_direcao, tipo_combustivel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement psSUV = conexao.prepareStatement(sqlSUV);
                psSUV.setInt(1, idVeiculo);
                psSUV.setInt(2, qtdPortas);
                psSUV.setInt(3, alturaSolo);
                psSUV.setInt(4, qtdAirbags);
                psSUV.setInt(5, capacidadePassageiros);
                psSUV.setBoolean(6, arCondicionado);
                psSUV.setBoolean(7, freioABS);
                psSUV.setBoolean(8, tracao4x4);
                psSUV.setString(9, tipoCambio);
                psSUV.setString(10, tipoDirecao);
                psSUV.setString(11, tipoCombustivel);
                psSUV.executeUpdate();

            } else if (panelCarreta.isVisible()) {
                // Captura dados Carreta
                double carga = Double.parseDouble(campoCarga.getText().trim());
                double comprimentoTotal = Double.parseDouble(campoComprimentoTotal.getText().trim());

                boolean articulada = rbArticuladaSim.isSelected();
                boolean rastreamentoGPS = rbRastreamentoGPSSim.isSelected();
                boolean refrigerada = rbRefrigeradaSim.isSelected();

                int qtdCompartimentos = Integer.parseInt(campoQtdCompartimentos.getText().trim());
                int numeroEixos = Integer.parseInt(campoNumeroEixos.getSelectedItem().toString().trim());

                String tipoCarroceria = campoTipoCarroceria.getText().trim();
                String tipoCarga = campoTipoCarga.getText().trim();

                String sqlCarreta = "INSERT INTO carreta (id_veiculo, carga, comprimento_total, articulada, rastreamento_gps, refrigerada, qtd_compartimentos, numero_eixos, tipo_carroceria, tipo_carga) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement psCarreta = conexao.prepareStatement(sqlCarreta);
                psCarreta.setInt(1, idVeiculo);
                psCarreta.setDouble(2, carga);
                psCarreta.setDouble(3, comprimentoTotal);
                psCarreta.setBoolean(4, articulada);
                psCarreta.setBoolean(5, rastreamentoGPS);
                psCarreta.setBoolean(6, refrigerada);
                psCarreta.setInt(7, qtdCompartimentos);
                psCarreta.setInt(8, numeroEixos);
                psCarreta.setString(9, tipoCarroceria);
                psCarreta.setString(10, tipoCarga);
                psCarreta.executeUpdate();
            } else {
                throw new IllegalStateException("Nenhum tipo de veículo selecionado.");
            }

            conexao.commit();
            JOptionPane.showMessageDialog(this, "Veículo cadastrado com sucesso!");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Erro: valores numéricos inválidos.", "Erro de Formato", JOptionPane.ERROR_MESSAGE);
            try { conexao.rollback(); } catch (SQLException ex) { /* Ignorar */ }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Erro: data de fabricação inválida.", "Erro de Data", JOptionPane.ERROR_MESSAGE);
            try { conexao.rollback(); } catch (SQLException ex) { /* Ignorar */ }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erro ao salvar no banco: " + e.getMessage(), "Erro de Banco", JOptionPane.ERROR_MESSAGE);
            try { conexao.rollback(); } catch (SQLException ex) { /* Ignorar */ }
        } catch (IllegalStateException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (conexao != null) conexao.setAutoCommit(true);
            } catch (SQLException ex) { /* Ignorar */ }
        }
    }

    private void configurarRadioButtons() {
        // Agrupa os dois radio buttons para seleção exclusiva
        ButtonGroup grupoOpcoes = new ButtonGroup();
        grupoOpcoes.add(opcaoCarreta);
        grupoOpcoes.add(opcaoSUV);

        // Esconde os painéis no início
        panelCarreta.setVisible(false);
        panelSUV.setVisible(false);

        // Listener para mostrar/ocultar painelCarreta
        opcaoCarreta.addActionListener(e -> {
            if (opcaoCarreta.isSelected()) {
                panelCarreta.setVisible(true);
                panelSUV.setVisible(false);
                verificarCampos(); 
            }
        });

        // Listener para mostrar/ocultar painelSUV
        opcaoSUV.addActionListener(e -> {
            if (opcaoSUV.isSelected()) {
                panelSUV.setVisible(true);
                panelCarreta.setVisible(false);
                verificarCampos(); 
            }
        });
    }

    private void configurarValidacaoCampos() {
        DocumentListener listener = new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { verificarCampos(); }
            @Override
            public void removeUpdate(DocumentEvent e) { verificarCampos(); }
            @Override
            public void changedUpdate(DocumentEvent e) { verificarCampos(); }
        };

        // JTextFields
        campoPlaca.getDocument().addDocumentListener(listener);
        campoModelo.getDocument().addDocumentListener(listener);
        campoPreco.getDocument().addDocumentListener(listener);
        campoMarca.getDocument().addDocumentListener(listener);
        campoCor.getDocument().addDocumentListener(listener);
        campoCarga.getDocument().addDocumentListener(listener);
        campoTipoCarroceria.getDocument().addDocumentListener(listener);
        campoQtdCompartimentos.getDocument().addDocumentListener(listener);
        campoTipoCarga.getDocument().addDocumentListener(listener);
        campoComprimentoTotal.getDocument().addDocumentListener(listener);
        campoAlturaSolo.getDocument().addDocumentListener(listener);
        campoQtdPassageiros.getDocument().addDocumentListener(listener);
        campoQtdAirbags.getDocument().addDocumentListener(listener);

        // JFormattedTextField
        campoDataFabricacao.getDocument().addDocumentListener(listener);

        // JComboBox
        campoNumeroEixos.addActionListener(e -> verificarCampos());
        campoQtdPortas.addActionListener(e -> verificarCampos());
        campoTipoCambio.addActionListener(e -> verificarCampos());
        campoTipoDirecao.addActionListener(e -> verificarCampos());
        campoTipoCombustivel.addActionListener(e -> verificarCampos());
    }


    private void verificarCampos() {
        boolean preenchido = !campoPlaca.getText().trim().isEmpty()
                && !campoModelo.getText().trim().isEmpty()
                && !campoPreco.getText().trim().isEmpty()
                && !campoMarca.getText().trim().isEmpty()
                && !campoCor.getText().trim().isEmpty()
                && !campoDataFabricacao.getText().trim().isEmpty();

        if (opcaoSUV.isSelected()) {
            preenchido = preenchido
                    && campoQtdPortas.getSelectedItem() != null && !campoQtdPortas.getSelectedItem().toString().trim().isEmpty()
                    && !campoAlturaSolo.getText().trim().isEmpty()
                    && !campoQtdAirbags.getText().trim().isEmpty()
                    && !campoQtdPassageiros.getText().trim().isEmpty()
                    && campoTipoCambio.getSelectedItem() != null && !campoTipoCambio.getSelectedItem().toString().trim().isEmpty()
                    && campoTipoDirecao.getSelectedItem() != null && !campoTipoDirecao.getSelectedItem().toString().trim().isEmpty()
                    && campoTipoCombustivel.getSelectedItem() != null && !campoTipoCombustivel.getSelectedItem().toString().trim().isEmpty();
        } else if (opcaoCarreta.isSelected()) {
            preenchido = preenchido
                    && !campoCarga.getText().trim().isEmpty()
                    && !campoComprimentoTotal.getText().trim().isEmpty()
                    && !campoQtdCompartimentos.getText().trim().isEmpty()
                    && campoNumeroEixos.getSelectedItem() != null && !campoNumeroEixos.getSelectedItem().toString().trim().isEmpty()
                    && campoTipoCarroceria.getText().trim().length() > 0
                    && campoTipoCarga.getText().trim().length() > 0;
        } else {
            preenchido = false;
        }

        btnSubmit.setEnabled(preenchido);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        campoPlaca = new javax.swing.JTextField();
        panelCarreta = new javax.swing.JInternalFrame();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        campoNumeroEixos = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        campoCarga = new javax.swing.JTextField();
        campoTipoCarroceria = new javax.swing.JTextField();
        rbArticuladaSim = new javax.swing.JRadioButton();
        rbRefrigeradaSim = new javax.swing.JRadioButton();
        rbRastreamentoGPSSim = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        campoQtdCompartimentos = new javax.swing.JTextField();
        campoTipoCarga = new javax.swing.JTextField();
        campoComprimentoTotal = new javax.swing.JTextField();
        panelSUV = new javax.swing.JInternalFrame();
        jLabel10 = new javax.swing.JLabel();
        campoQtdPortas = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        campoTipoDirecao = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        campoTipoCambio = new javax.swing.JComboBox<>();
        rbFreioABSSim = new javax.swing.JRadioButton();
        rbTracao4x4Sim = new javax.swing.JRadioButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        campoQtdPassageiros = new javax.swing.JTextField();
        campoQtdAirbags = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        rbArCondicionadoSim = new javax.swing.JRadioButton();
        campoAlturaSolo = new javax.swing.JTextField();
        campoTipoCombustivel = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        campoModelo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        campoPreco = new javax.swing.JTextField();
        campoDataFabricacao = new javax.swing.JFormattedTextField();
        campoMarca = new javax.swing.JTextField();
        btnVoltar = new javax.swing.JButton();
        btnSubmit = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        campoCor = new javax.swing.JTextField();
        opcaoSUV = new javax.swing.JRadioButton();
        opcaoCarreta = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(590, 590));

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));

        jLabel1.setFont(new java.awt.Font("Adwaita Sans", 0, 18)); // NOI18N
        jLabel1.setText("Cadastrar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(37, 37, 37))
        );

        jLabel2.setText("Placa:");

        campoPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoPlacaActionPerformed(evt);
            }
        });

        panelCarreta.setTitle("Carreta");
        panelCarreta.setVisible(true);

        jLabel7.setText("Carga:");

        jLabel8.setText("Numero eixos:");

        campoNumeroEixos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9" }));
        campoNumeroEixos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoNumeroEixosActionPerformed(evt);
            }
        });

        jLabel9.setText("Tipo de Carroceria:");

        rbArticuladaSim.setText("Articulado");

        rbRefrigeradaSim.setText("Resfriado");

        rbRastreamentoGPSSim.setText("Rastreamento GPS");
        rbRastreamentoGPSSim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbRastreamentoGPSSimActionPerformed(evt);
            }
        });

        jLabel12.setText("Tipo Carga:");

        jLabel13.setText("Comprimento:");

        jLabel14.setText("qtd Compartimento:");

        campoQtdCompartimentos.setMinimumSize(new java.awt.Dimension(64, 50));
        campoQtdCompartimentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoQtdCompartimentosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelCarretaLayout = new javax.swing.GroupLayout(panelCarreta.getContentPane());
        panelCarreta.getContentPane().setLayout(panelCarretaLayout);
        panelCarretaLayout.setHorizontalGroup(
            panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCarretaLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCarretaLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoTipoCarroceria))
                            .addGroup(panelCarretaLayout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(campoCarga)))
                        .addGap(46, 46, 46))
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbRastreamentoGPSSim)
                            .addComponent(rbRefrigeradaSim)
                            .addComponent(rbArticuladaSim))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoTipoCarga))
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(campoComprimentoTotal, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelCarretaLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(campoNumeroEixos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoQtdCompartimentos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(21, 21, 21))
        );
        panelCarretaLayout.setVerticalGroup(
            panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelCarretaLayout.createSequentialGroup()
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(campoCarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(campoNumeroEixos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(campoTipoCarroceria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(campoQtdCompartimentos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rbArticuladaSim)
                        .addComponent(campoTipoCarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbRefrigeradaSim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbRastreamentoGPSSim))
                    .addGroup(panelCarretaLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(panelCarretaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(campoComprimentoTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelSUV.setTitle("SUV");
        panelSUV.setVisible(true);

        jLabel10.setText("qtd Portas");

        campoQtdPortas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "" }));

        jLabel15.setText("Tipo de direção:");

        campoTipoDirecao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mecânica ", "Hidráulica", "Elétrica", "Eletro-hidráulica" }));

        jLabel16.setText("Tipo de Cambio:");

        campoTipoCambio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manual", "Automático", "CVT", "Automatizado" }));

        rbFreioABSSim.setText("Freio ABS");

        rbTracao4x4Sim.setText("Tração 4X4");

        jLabel17.setText("Altura:");

        jLabel18.setText("qtdPassageiros: ");

        jLabel19.setText("qtd Airbags:");

        jLabel20.setText("Tipo de combustível:");

        rbArCondicionadoSim.setText("arCondicionado");

        campoTipoCombustivel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gasolina", "Flex", "Etanol", "Diesel", "Híbrido" }));

        javax.swing.GroupLayout panelSUVLayout = new javax.swing.GroupLayout(panelSUV.getContentPane());
        panelSUV.getContentPane().setLayout(panelSUVLayout);
        panelSUVLayout.setHorizontalGroup(
            panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSUVLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSUVLayout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoTipoCambio, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSUVLayout.createSequentialGroup()
                                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelSUVLayout.createSequentialGroup()
                                        .addComponent(jLabel15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoTipoDirecao, 0, 150, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelSUVLayout.createSequentialGroup()
                                        .addComponent(rbFreioABSSim)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(panelSUVLayout.createSequentialGroup()
                                        .addComponent(jLabel20)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoTipoCombustivel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGap(8, 8, 8)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(18, 18, 18)
                        .addComponent(campoAlturaSolo, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)))
                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(rbTracao4x4Sim)
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoQtdPortas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoQtdPassageiros, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(campoQtdAirbags))
                    .addComponent(rbArCondicionadoSim))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelSUVLayout.setVerticalGroup(
            panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSUVLayout.createSequentialGroup()
                .addGap(0, 18, Short.MAX_VALUE)
                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(campoAlturaSolo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(rbFreioABSSim)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelSUVLayout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(campoTipoDirecao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(campoTipoCambio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelSUVLayout.createSequentialGroup()
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(campoQtdPortas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbTracao4x4Sim)
                        .addGap(9, 9, 9)
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(campoQtdPassageiros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(campoQtdAirbags, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(14, 14, 14)
                .addGroup(panelSUVLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(rbArCondicionadoSim)
                    .addComponent(campoTipoCombustivel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17))
        );

        jLabel3.setText("Modelo:");

        jLabel4.setText("Data Fabricação:");

        campoModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoModeloActionPerformed(evt);
            }
        });

        jLabel5.setText("Marca:");

        jLabel6.setText("Preço:");

        try {
            campoDataFabricacao.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        campoDataFabricacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoDataFabricacaoActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        jLabel11.setText("Cor:");

        opcaoSUV.setText("SUV");
        opcaoSUV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcaoSUVActionPerformed(evt);
            }
        });

        opcaoCarreta.setText("Carreta");
        opcaoCarreta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcaoCarretaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelSUV)
                    .addComponent(panelCarreta, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnVoltar)
                        .addGap(407, 407, 407)
                        .addComponent(btnSubmit)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(281, 281, 281))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(opcaoSUV)
                                                .addGap(18, 18, 18)
                                                .addComponent(opcaoCarreta))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel6)
                                                .addGap(18, 18, 18)
                                                .addComponent(campoPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(76, 76, 76))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(campoPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(76, 76, 76)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(campoMarca))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(campoDataFabricacao))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoCor, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(campoPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(campoDataFabricacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(campoMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(campoModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(campoPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(campoCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(opcaoSUV)
                    .addComponent(opcaoCarreta))
                .addGap(2, 2, 2)
                .addComponent(panelCarreta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelSUV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar)
                    .addComponent(btnSubmit))
                .addContainerGap())
        );

        btnSubmit.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void campoPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoPlacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoPlacaActionPerformed

    private void campoModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoModeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoModeloActionPerformed

    private void campoDataFabricacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoDataFabricacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoDataFabricacaoActionPerformed

    private void campoNumeroEixosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoNumeroEixosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoNumeroEixosActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        try {
            cadastrarVeiculo();  // Faz todo o cadastro, incluindo dados específicos
            this.dispose();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar veículo: " + e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void opcaoSUVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcaoSUVActionPerformed
        
    }//GEN-LAST:event_opcaoSUVActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void opcaoCarretaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcaoCarretaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_opcaoCarretaActionPerformed

    private void rbRastreamentoGPSSimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbRastreamentoGPSSimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbRastreamentoGPSSimActionPerformed

    private void campoQtdCompartimentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoQtdCompartimentosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoQtdCompartimentosActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Cadastrar().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSubmit;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JTextField campoAlturaSolo;
    private javax.swing.JTextField campoCarga;
    private javax.swing.JTextField campoComprimentoTotal;
    private javax.swing.JTextField campoCor;
    private javax.swing.JFormattedTextField campoDataFabricacao;
    private javax.swing.JTextField campoMarca;
    private javax.swing.JTextField campoModelo;
    private javax.swing.JComboBox<String> campoNumeroEixos;
    private javax.swing.JTextField campoPlaca;
    private javax.swing.JTextField campoPreco;
    private javax.swing.JTextField campoQtdAirbags;
    private javax.swing.JTextField campoQtdCompartimentos;
    private javax.swing.JTextField campoQtdPassageiros;
    private javax.swing.JComboBox<String> campoQtdPortas;
    private javax.swing.JComboBox<String> campoTipoCambio;
    private javax.swing.JTextField campoTipoCarga;
    private javax.swing.JTextField campoTipoCarroceria;
    private javax.swing.JComboBox<String> campoTipoCombustivel;
    private javax.swing.JComboBox<String> campoTipoDirecao;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton opcaoCarreta;
    private javax.swing.JRadioButton opcaoSUV;
    private javax.swing.JInternalFrame panelCarreta;
    private javax.swing.JInternalFrame panelSUV;
    private javax.swing.JRadioButton rbArCondicionadoSim;
    private javax.swing.JRadioButton rbArticuladaSim;
    private javax.swing.JRadioButton rbFreioABSSim;
    private javax.swing.JRadioButton rbRastreamentoGPSSim;
    private javax.swing.JRadioButton rbRefrigeradaSim;
    private javax.swing.JRadioButton rbTracao4x4Sim;
    // End of variables declaration//GEN-END:variables
}
