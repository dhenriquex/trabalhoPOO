package trabalho_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Statement;
import javax.swing.JOptionPane;

public class Edit extends javax.swing.JFrame {
     static String driverJDBC =
            "com.mysql.cj.jdbc.Driver";
   static String url = "jdbc:mysql://127.0.0.1:3306/veiculos";


    static String user = "root";
    static String senha = "Davi100445#";
    Connection conexao;
    
    public Edit() {
        initComponents();
        
        //Carregando o driver
        try{
            Class.forName(driverJDBC);
            System.out.println(
                    "Driver carregado!");
        }catch(Exception e){
            System.out.println(
             "Falha carregamento driver!");
        }
        //Estabelecendo a conexão
        try{
            conexao = DriverManager.
               getConnection(url, user, senha);
            System.out.println(
                    "Conexão estabelecida!");
        }catch(Exception e){
            System.out.println(
             "Falha na conexão!");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tfPlaca = new javax.swing.JTextField();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cbNumeroEixos = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        ftCarga = new javax.swing.JTextField();
        tfTipoCarroceria = new javax.swing.JTextField();
        btnArticulado = new javax.swing.JRadioButton();
        btnResfriado = new javax.swing.JRadioButton();
        btnRastreio = new javax.swing.JRadioButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tfqtdCompartimento = new javax.swing.JTextField();
        ftTipoCarga = new javax.swing.JTextField();
        tfComprimento = new javax.swing.JTextField();
        jInternalFrame2 = new javax.swing.JInternalFrame();
        btnArCondicionado = new javax.swing.JRadioButton();
        jLabel10 = new javax.swing.JLabel();
        cbQtdPortas = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        cbTipoDirecao = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        cbTipoCambio = new javax.swing.JComboBox<>();
        btnFreioABS = new javax.swing.JRadioButton();
        btnTracao = new javax.swing.JRadioButton();
        jLabel17 = new javax.swing.JLabel();
        tfAltura = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        qtdPassageiro = new javax.swing.JTextField();
        tfAirbags = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfModelo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfPreco = new javax.swing.JTextField();
        ffDataFabricacao = new javax.swing.JFormattedTextField();
        ftMarca = new javax.swing.JTextField();
        btnVoltar = new javax.swing.JButton();
        btnSubmit = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        tfCor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 255));

        jLabel1.setFont(new java.awt.Font("Adwaita Sans", 0, 18)); // NOI18N
        jLabel1.setText("EDITAR");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(37, 37, 37))
        );

        jLabel2.setText("Placa:");

        tfPlaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPlacaActionPerformed(evt);
            }
        });

        jInternalFrame1.setTitle("Veiculo de Carga");
        jInternalFrame1.setVisible(true);

        jLabel7.setText("Carga:");

        jLabel8.setText("Numero eixos:");

        cbNumeroEixos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9" }));
        cbNumeroEixos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbNumeroEixosActionPerformed(evt);
            }
        });

        jLabel9.setText("Tipo de Carroceria:");

        ftCarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftCargaActionPerformed(evt);
            }
        });

        tfTipoCarroceria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTipoCarroceriaActionPerformed(evt);
            }
        });

        btnArticulado.setText("Articulado");
        btnArticulado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArticuladoActionPerformed(evt);
            }
        });

        btnResfriado.setText("Resfriado");
        btnResfriado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResfriadoActionPerformed(evt);
            }
        });

        btnRastreio.setText("Rastreamento GPS");
        btnRastreio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRastreioActionPerformed(evt);
            }
        });

        jLabel12.setText("Tipo Carga:");

        jLabel13.setText("Comprimento:");

        jLabel14.setText("qtd Compartimento:");

        tfqtdCompartimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfqtdCompartimentoActionPerformed(evt);
            }
        });

        ftTipoCarga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftTipoCargaActionPerformed(evt);
            }
        });

        tfComprimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfComprimentoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfTipoCarroceria, javax.swing.GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
                            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(ftCarga)))
                        .addGap(76, 76, 76))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnRastreio)
                            .addComponent(btnResfriado)
                            .addComponent(btnArticulado))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfqtdCompartimento))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ftTipoCarga))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfComprimento, javax.swing.GroupLayout.DEFAULT_SIZE, 168, Short.MAX_VALUE))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(cbNumeroEixos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(21, 21, 21))
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jInternalFrame1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(ftCarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(cbNumeroEixos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tfTipoCarroceria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14)
                    .addComponent(tfqtdCompartimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnArticulado)
                        .addComponent(ftTipoCarga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnResfriado)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRastreio))
                    .addGroup(jInternalFrame1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(tfComprimento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jInternalFrame2.setTitle("Veiculo de Passeio");
        jInternalFrame2.setVisible(true);

        btnArCondicionado.setText("arCondicionado");
        btnArCondicionado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnArCondicionadoActionPerformed(evt);
            }
        });

        jLabel10.setText("qtd Portas");

        cbQtdPortas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", " " }));
        cbQtdPortas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbQtdPortasActionPerformed(evt);
            }
        });

        jLabel15.setText("Tipo de direção:");

        cbTipoDirecao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Mecânica ", "Hidráulica", "Elétrica", "Eletro-hidráulica" }));
        cbTipoDirecao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbTipoDirecaoActionPerformed(evt);
            }
        });

        jLabel16.setText("Tipo de Cambio:");

        cbTipoCambio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Manual", "Automático", "CVT", "Automatizado" }));
        cbTipoCambio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbTipoCambioActionPerformed(evt);
            }
        });

        btnFreioABS.setText("Freio ABS");
        btnFreioABS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFreioABSActionPerformed(evt);
            }
        });

        btnTracao.setText("Tração 4X4");
        btnTracao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTracaoActionPerformed(evt);
            }
        });

        jLabel17.setText("Altura:");

        tfAltura.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfAlturaActionPerformed(evt);
            }
        });

        jLabel18.setText("qtdPassageiro: ");

        jLabel19.setText("qtd Airbags:");

        qtdPassageiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qtdPassageiroActionPerformed(evt);
            }
        });

        tfAirbags.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfAirbagsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jInternalFrame2Layout = new javax.swing.GroupLayout(jInternalFrame2.getContentPane());
        jInternalFrame2.getContentPane().setLayout(jInternalFrame2Layout);
        jInternalFrame2Layout.setHorizontalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnFreioABS)
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbTipoDirecao, 0, 1, Short.MAX_VALUE))
                    .addComponent(btnArCondicionado)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbTipoCambio, 0, 1, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfAltura, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnTracao)
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbQtdPortas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(qtdPassageiro))
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfAirbags, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 35, 35))
        );
        jInternalFrame2Layout.setVerticalGroup(
            jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jInternalFrame2Layout.createSequentialGroup()
                .addGap(0, 18, Short.MAX_VALUE)
                .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(tfAltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(btnFreioABS)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel16)
                            .addComponent(cbTipoCambio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(cbTipoDirecao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jInternalFrame2Layout.createSequentialGroup()
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(cbQtdPortas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTracao)
                        .addGap(9, 9, 9)
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(qtdPassageiro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jInternalFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(tfAirbags, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addComponent(btnArCondicionado)
                .addGap(18, 18, 18))
        );

        jLabel3.setText("Modelo:");

        jLabel4.setText("Data Fabricação:");

        tfModelo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfModeloActionPerformed(evt);
            }
        });

        jLabel5.setText("Marca:");

        jLabel6.setText("Preço:");

        tfPreco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPrecoActionPerformed(evt);
            }
        });

        try {
            ffDataFabricacao.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        ffDataFabricacao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ffDataFabricacaoActionPerformed(evt);
            }
        });

        ftMarca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ftMarcaActionPerformed(evt);
            }
        });

        btnVoltar.setText("Voltar");
        btnVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoltarActionPerformed(evt);
            }
        });

        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        jLabel11.setText("Cor:");

        tfCor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(btnVoltar)
                                .addGap(407, 407, 407)
                                .addComponent(btnSubmit))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(281, 281, 281))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(tfModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGap(15, 15, 15)
                                                .addComponent(jLabel6)
                                                .addGap(18, 18, 18)
                                                .addComponent(tfPreco, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGap(76, 76, 76))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(tfPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(76, 76, 76)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ftMarca))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(ffDataFabricacao, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 47, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(tfCor)))))
                        .addGap(72, 72, 72))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jInternalFrame1)
                            .addComponent(jInternalFrame2))
                        .addGap(17, 17, 17))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(ffDataFabricacao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(ftMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(tfModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(tfPreco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(tfCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jInternalFrame2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnVoltar)
                    .addComponent(btnSubmit))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfPlacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPlacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfPlacaActionPerformed

    private void tfModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfModeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfModeloActionPerformed

    private void ffDataFabricacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ffDataFabricacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ffDataFabricacaoActionPerformed

    private void cbNumeroEixosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbNumeroEixosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbNumeroEixosActionPerformed

    private void tfPrecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPrecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfPrecoActionPerformed

    private void tfCorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfCorActionPerformed

    private void ftMarcaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftMarcaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftMarcaActionPerformed

    private void ftCargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftCargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftCargaActionPerformed

    private void tfTipoCarroceriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTipoCarroceriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTipoCarroceriaActionPerformed

    private void btnArticuladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArticuladoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnArticuladoActionPerformed

    private void btnResfriadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResfriadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnResfriadoActionPerformed

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        String sqlAtualizarVeiculo = "UPDATE veiculo SET cor = ?, marca = ?, modelo = ?, data_fabricacao = ?, preco = ? WHERE placa = ?";

        try {
            // Validações básicas antes de iniciar a transação
            if (tfPlaca.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, informe a placa do veículo para localizar o registro.", "Campo Obrigatório", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Validação de campos obrigatórios apenas se não estiverem vazios
            StringBuilder erros = new StringBuilder();

            if (!tfCor.getText().trim().isEmpty() && tfCor.getText().trim().length() < 2) {
                erros.append("- Cor deve ter pelo menos 2 caracteres\n");
            }
            if (!ftMarca.getText().trim().isEmpty() && ftMarca.getText().trim().length() < 2) {
                erros.append("- Marca deve ter pelo menos 2 caracteres\n");
            }
            if (!tfModelo.getText().trim().isEmpty() && tfModelo.getText().trim().length() < 2) {
                erros.append("- Modelo deve ter pelo menos 2 caracteres\n");
            }
            if (!tfPreco.getText().trim().isEmpty()) {
                try {
                    double preco = Double.parseDouble(tfPreco.getText().trim());
                    if (preco <= 0) {
                        erros.append("- Preço deve ser maior que zero\n");
                    }
                } catch (NumberFormatException e) {
                    erros.append("- Preço deve ser um número válido\n");
                }
            }

            if (erros.length() > 0) {
                JOptionPane.showMessageDialog(this, 
                    "Corrija os seguintes problemas:\n\n" + erros.toString(), 
                    "Dados Inválidos", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            conexao.setAutoCommit(false); // Início da transação

            // Atualiza os dados da tabela veiculo apenas se os campos não estiverem vazios
            PreparedStatement stmtAtualizarVeiculo = conexao.prepareStatement(sqlAtualizarVeiculo);

            // Se o campo estiver vazio, busca o valor atual do banco
            String sqlBuscarAtual = "SELECT cor, marca, modelo, data_fabricacao, preco FROM veiculo WHERE placa = ?";
            PreparedStatement stmtBuscar = conexao.prepareStatement(sqlBuscarAtual);
            stmtBuscar.setString(1, tfPlaca.getText().trim());
            ResultSet rsAtual = stmtBuscar.executeQuery();

            if (rsAtual.next()) {
                // Usa o valor do campo se preenchido, senão mantém o valor atual do banco
                stmtAtualizarVeiculo.setString(1, !tfCor.getText().trim().isEmpty() ? tfCor.getText().trim() : rsAtual.getString("cor"));
                stmtAtualizarVeiculo.setString(2, !ftMarca.getText().trim().isEmpty() ? ftMarca.getText().trim() : rsAtual.getString("marca"));
                stmtAtualizarVeiculo.setString(3, !tfModelo.getText().trim().isEmpty() ? tfModelo.getText().trim() : rsAtual.getString("modelo"));
                stmtAtualizarVeiculo.setString(4, !ffDataFabricacao.getText().trim().isEmpty() ? ffDataFabricacao.getText().trim() : rsAtual.getString("data_fabricacao"));
                stmtAtualizarVeiculo.setDouble(5, !tfPreco.getText().trim().isEmpty() ? Double.parseDouble(tfPreco.getText().trim()) : rsAtual.getDouble("preco"));
                stmtAtualizarVeiculo.setString(6, tfPlaca.getText().trim());
            } else {
                conexao.rollback();
                conexao.setAutoCommit(true);
                JOptionPane.showMessageDialog(this, 
                    "Veículo com placa '" + tfPlaca.getText().trim() + "' não foi encontrado no sistema.\nVerifique se a placa está correta.", 
                    "Veículo não encontrado", 
                    JOptionPane.WARNING_MESSAGE);
                return;
            }

            int linhasAfetadas = stmtAtualizarVeiculo.executeUpdate();

            if (linhasAfetadas > 0) {
                // Buscar o ID e o tipo do veículo
                String sqlBuscarIdETipo = "SELECT id, tipo FROM veiculo WHERE placa = ?";
                PreparedStatement stmtBuscarId = conexao.prepareStatement(sqlBuscarIdETipo);
                stmtBuscarId.setString(1, tfPlaca.getText().trim());
                ResultSet resultadoBusca = stmtBuscarId.executeQuery();

                if (resultadoBusca.next()) {
                    int idVeiculo = resultadoBusca.getInt("id");
                    String tipoVeiculo = resultadoBusca.getString("tipo");

                    boolean sucessoTipoEspecifico = true;

                    if ("carga".equals(tipoVeiculo)) {
                        // Busca valores atuais da tabela veiculo_carga
                        String sqlBuscarCarga = "SELECT * FROM veiculo_carga WHERE id = ?";
                        PreparedStatement stmtBuscarCarga = conexao.prepareStatement(sqlBuscarCarga);
                        stmtBuscarCarga.setInt(1, idVeiculo);
                        ResultSet rsCarga = stmtBuscarCarga.executeQuery();

                        if (rsCarga.next()) {
                            // Atualiza dados da tabela veiculo_carga
                            String sqlAtualizarCarga = "UPDATE veiculo_carga SET numero_eixos = ?, carga = ?, tipo_carroceria = ?, " +
                                    "articulada = ?, rastreamento_gps = ?, refrigerada = ?, comprimento_total = ?, " +
                                    "qtd_compartimentos = ?, tipo_carga = ? WHERE id = ?";

                            PreparedStatement stmtCarga = conexao.prepareStatement(sqlAtualizarCarga);

                            // Validação de campos específicos de carga
                            String carregaText = ftCarga.getText().trim();
                            String comprimentoText = tfComprimento.getText().trim();
                            String qtdCompartimentoText = tfqtdCompartimento.getText().trim();

                            try {
                                stmtCarga.setInt(1, cbNumeroEixos.getSelectedItem() != null ? Integer.parseInt(cbNumeroEixos.getSelectedItem().toString()) : rsCarga.getInt("numero_eixos"));
                                stmtCarga.setDouble(2, !carregaText.isEmpty() ? Double.parseDouble(carregaText) : rsCarga.getDouble("carga"));
                                stmtCarga.setString(3, !tfTipoCarroceria.getText().trim().isEmpty() ? tfTipoCarroceria.getText().trim() : rsCarga.getString("tipo_carroceria"));
                                stmtCarga.setBoolean(4, btnArticulado.isSelected());
                                stmtCarga.setBoolean(5, btnRastreio.isSelected());
                                stmtCarga.setBoolean(6, btnResfriado.isSelected());
                                stmtCarga.setDouble(7, !comprimentoText.isEmpty() ? Double.parseDouble(comprimentoText) : rsCarga.getDouble("comprimento_total"));
                                stmtCarga.setInt(8, !qtdCompartimentoText.isEmpty() ? Integer.parseInt(qtdCompartimentoText) : rsCarga.getInt("qtd_compartimentos"));
                                stmtCarga.setString(9, !ftTipoCarga.getText().trim().isEmpty() ? ftTipoCarga.getText().trim() : rsCarga.getString("tipo_carga"));
                                stmtCarga.setInt(10, idVeiculo);

                                int linhasAfetadasCarga = stmtCarga.executeUpdate();
                                if (linhasAfetadasCarga == 0) {
                                    sucessoTipoEspecifico = false;
                                    JOptionPane.showMessageDialog(this, "Erro ao atualizar dados específicos do veículo de carga.", "Erro de Atualização", JOptionPane.ERROR_MESSAGE);
                                }
                            } catch (NumberFormatException ex) {
                                sucessoTipoEspecifico = false;
                                JOptionPane.showMessageDialog(this, 
                                    "Erro nos dados numéricos do veículo de carga:\n" + 
                                    "Verifique os campos de carga, comprimento e quantidade de compartimentos.\n" +
                                    "Use apenas números e vírgula/ponto decimal.", 
                                    "Erro de Formato", 
                                    JOptionPane.ERROR_MESSAGE);
                            }
                        }

                    } else if ("passeio".equals(tipoVeiculo)) {
                        // Busca valores atuais da tabela veiculo_passeio
                        String sqlBuscarPasseio = "SELECT * FROM veiculo_passeio WHERE id = ?";
                        PreparedStatement stmtBuscarPasseio = conexao.prepareStatement(sqlBuscarPasseio);
                        stmtBuscarPasseio.setInt(1, idVeiculo);
                        ResultSet rsPasseio = stmtBuscarPasseio.executeQuery();

                        if (rsPasseio.next()) {
                            // Atualiza dados da tabela veiculo_passeio
                            String sqlAtualizarPasseio = "UPDATE veiculo_passeio SET qtd_portas = ?, ar_condicionado = ?, " +
                                    "tipo_cambio = ?, tipo_direcao = ? WHERE id = ?";

                            PreparedStatement stmtPasseio = conexao.prepareStatement(sqlAtualizarPasseio);
                            stmtPasseio.setInt(1, cbQtdPortas.getSelectedItem() != null ? Integer.parseInt(cbQtdPortas.getSelectedItem().toString()) : rsPasseio.getInt("qtd_portas"));
                            stmtPasseio.setBoolean(2, btnArCondicionado.isSelected());
                            stmtPasseio.setString(3, cbTipoCambio.getSelectedItem() != null ? cbTipoCambio.getSelectedItem().toString() : rsPasseio.getString("tipo_cambio"));
                            stmtPasseio.setString(4, cbTipoDirecao.getSelectedItem() != null ? cbTipoDirecao.getSelectedItem().toString() : rsPasseio.getString("tipo_direcao"));
                            stmtPasseio.setInt(5, idVeiculo);

                            int linhasAfetadasPasseio = stmtPasseio.executeUpdate();
                            if (linhasAfetadasPasseio == 0) {
                                sucessoTipoEspecifico = false;
                                JOptionPane.showMessageDialog(this, "Erro ao atualizar dados específicos do veículo de passeio.", "Erro de Atualização", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }

                    if (sucessoTipoEspecifico) {
                        conexao.commit();
                        conexao.setAutoCommit(true);

                        JOptionPane.showMessageDialog(this, 
                            "Veículo atualizado com sucesso!\n" + 
                            "Placa: " + tfPlaca.getText().trim() + "\n" +
                            "Tipo: " + tipoVeiculo.toUpperCase() + "\n" +
                            "Apenas os campos preenchidos foram alterados.", 
                            "Sucesso", 
                            JOptionPane.INFORMATION_MESSAGE);
                        System.out.println("Alteração realizada com sucesso para veículo: " + tfPlaca.getText().trim());
                    } else {
                        conexao.rollback();
                        conexao.setAutoCommit(true);
                    }

                } else {
                    conexao.rollback();
                    conexao.setAutoCommit(true);
                    JOptionPane.showMessageDialog(this, 
                        "Erro interno: Veículo não encontrado após atualização.\nContate o suporte técnico.", 
                        "Erro Interno", 
                        JOptionPane.ERROR_MESSAGE);
                }

            } else {
                conexao.rollback();
                conexao.setAutoCommit(true);
                JOptionPane.showMessageDialog(this, 
                    "Veículo com placa '" + tfPlaca.getText().trim() + "' não foi encontrado no sistema.\nVerifique se a placa está correta.", 
                    "Veículo não encontrado", 
                    JOptionPane.WARNING_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            try {
                conexao.rollback();
                conexao.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            JOptionPane.showMessageDialog(this, 
                "Erro nos dados numéricos informados:\n" + 
                "Verifique se os campos de preço, carga e outros valores numéricos estão corretos.\n" +
                "Use apenas números e vírgula/ponto decimal quando necessário.", 
                "Erro de Formato", 
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();

        } catch (SQLException ex) {
            try {
                conexao.rollback();
                conexao.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            String mensagemErro = "Erro ao atualizar veículo no banco de dados:\n";

            // Mensagens mais específicas para erros comuns de SQL
            if (ex.getMessage().contains("Duplicate entry")) {
                mensagemErro += "Já existe um veículo com esta placa no sistema.";
            } else if (ex.getMessage().contains("cannot be null")) {
                mensagemErro += "Campos obrigatórios não podem ficar vazios.";
            } else if (ex.getMessage().contains("foreign key")) {
                mensagemErro += "Referência inválida no banco de dados. Contate o suporte.";
            } else if (ex.getMessage().contains("Data truncation")) {
                mensagemErro += "Dados muito longos para o campo. Verifique o tamanho dos textos.";
            } else if (ex.getMessage().contains("Connection")) {
                mensagemErro += "Problema de conexão com o banco de dados. Tente novamente.";
            } else {
                mensagemErro += ex.getMessage();
            }

            JOptionPane.showMessageDialog(this, mensagemErro, "Erro de Banco de Dados", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();

        } catch (Exception ex) {
            try {
                conexao.rollback();
                conexao.setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }

            JOptionPane.showMessageDialog(this, 
                "Erro inesperado ao atualizar veículo:\n" + ex.getMessage() + 
                "\n\nSe o problema persistir, contate o suporte técnico.", 
                "Erro Inesperado", 
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoltarActionPerformed
       try {
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
                System.out.println("Conexão encerrada");
            }
        } catch (Exception e) {
            System.out.println("Falha ao fechar: " + e.getMessage());
        }
        this.dispose();
    }//GEN-LAST:event_btnVoltarActionPerformed

    private void btnArCondicionadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnArCondicionadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnArCondicionadoActionPerformed

    private void tfAirbagsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfAirbagsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfAirbagsActionPerformed

    private void qtdPassageiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qtdPassageiroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_qtdPassageiroActionPerformed

    private void btnTracaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTracaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnTracaoActionPerformed

    private void cbQtdPortasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbQtdPortasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbQtdPortasActionPerformed

    private void cbTipoDirecaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbTipoDirecaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbTipoDirecaoActionPerformed

    private void cbTipoCambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbTipoCambioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbTipoCambioActionPerformed

    private void btnFreioABSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFreioABSActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnFreioABSActionPerformed

    private void tfAlturaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfAlturaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfAlturaActionPerformed

    private void btnRastreioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRastreioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnRastreioActionPerformed

    private void tfqtdCompartimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfqtdCompartimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfqtdCompartimentoActionPerformed

    private void ftTipoCargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ftTipoCargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ftTipoCargaActionPerformed

    private void tfComprimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfComprimentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfComprimentoActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new Edit().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton btnArCondicionado;
    private javax.swing.JRadioButton btnArticulado;
    private javax.swing.JRadioButton btnFreioABS;
    private javax.swing.JRadioButton btnRastreio;
    private javax.swing.JRadioButton btnResfriado;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JRadioButton btnTracao;
    private javax.swing.JButton btnVoltar;
    private javax.swing.JComboBox<String> cbNumeroEixos;
    private javax.swing.JComboBox<String> cbQtdPortas;
    private javax.swing.JComboBox<String> cbTipoCambio;
    private javax.swing.JComboBox<String> cbTipoDirecao;
    private javax.swing.JFormattedTextField ffDataFabricacao;
    private javax.swing.JTextField ftCarga;
    private javax.swing.JTextField ftMarca;
    private javax.swing.JTextField ftTipoCarga;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JInternalFrame jInternalFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField qtdPassageiro;
    private javax.swing.JTextField tfAirbags;
    private javax.swing.JTextField tfAltura;
    private javax.swing.JTextField tfComprimento;
    private javax.swing.JTextField tfCor;
    private javax.swing.JTextField tfModelo;
    private javax.swing.JTextField tfPlaca;
    private javax.swing.JTextField tfPreco;
    private javax.swing.JTextField tfTipoCarroceria;
    private javax.swing.JTextField tfqtdCompartimento;
    // End of variables declaration//GEN-END:variables
}
